package com.poc.entity;


import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class GemsMobileDktItemDtls {
	
	@Id
	private int pkgNo;
	
	private String userId;
	
	@ManyToOne
    @JoinColumn(name = "docket_no")
	@JsonProperty("docketNo")
    private GemsMobileDktMst gemsMobileDktMst;

	public int getPkgNo() {
		return pkgNo;
	}

	public void setPkgNo(int pkgNo) {
		this.pkgNo = pkgNo;
	}

	public GemsMobileDktMst getGemsMobileDktMst() {
		return gemsMobileDktMst;
	}

	public void setGemsMobileDktMst(GemsMobileDktMst gemsMobileDktMst) {
		this.gemsMobileDktMst = gemsMobileDktMst;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	
	
	
}
