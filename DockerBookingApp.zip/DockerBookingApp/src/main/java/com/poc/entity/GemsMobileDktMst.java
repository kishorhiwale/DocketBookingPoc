package com.poc.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Data
@Getter
@Setter
public class GemsMobileDktMst {
	@Id
	private int docketNo;
	
	@JsonProperty("BILLING_OU")
	private String billingOu;

	@OneToMany(mappedBy = "gemsMobileDktMst", cascade = CascadeType.ALL)
	private List<GemsMobileDktItemDtls> gemsMobileDktItemDtls;

	public int getDocketNo() {
		return docketNo;
	}

	public void setDocketNo(int docketNo) {
		this.docketNo = docketNo;
	}

	public String getBillingOu() {
		return billingOu;
	}

	public void setBillingOu(String billingOu) {
		this.billingOu = billingOu;
	}

	public List<GemsMobileDktItemDtls> getGemsMobileDktItemDtls() {
		return gemsMobileDktItemDtls;
	}

	public void setGemsMobileDktItemDtls(List<GemsMobileDktItemDtls> gemsMobileDktItemDtls) {
		this.gemsMobileDktItemDtls = gemsMobileDktItemDtls;
	}

	

	
	

	
	
}

