package com.poc.serviceImpl;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.dto.PackageInfo;
import com.poc.dto.RequestPayload;
import com.poc.entity.GemsMobileDktItemDtls;
import com.poc.entity.GemsMobileDktMst;
import com.poc.repo.GemsMobileDktItemDtlsRepo;
import com.poc.repo.GemsMobileDktMstRepo;
import com.poc.service.BookingService;

import jakarta.transaction.Transactional;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	GemsMobileDktItemDtlsRepo dktItemDtlsRepo;

	@Autowired
	GemsMobileDktMstRepo dktMstRepo;

	@Override
	@Transactional
	public RequestPayload saveBookingInfo(RequestPayload requestPayload) {

		
		boolean isDeleted = dktItemDtlsRepo.deleteByDocketNo(requestPayload.getBookingInfo().getDocketNo());
		System.out.println(requestPayload.getBookingInfo().getDocketNo()+" : " + isDeleted );
		
		System.out.println(requestPayload);
		
		
		GemsMobileDktMst gemsMobileDktMst = new GemsMobileDktMst();
		gemsMobileDktMst.setDocketNo(requestPayload.getBookingInfo().getDocketNo());
		gemsMobileDktMst.setBillingOu(requestPayload.getBookingInfo().getBillingOu());
		
		
		GemsMobileDktItemDtls gemsMobileDktItemDtls = new GemsMobileDktItemDtls();
		PackageInfo packageInfo =  requestPayload.getPackageInfo().stream().findFirst().get();
		gemsMobileDktItemDtls.setPkgNo(packageInfo.getPkgNo());
		gemsMobileDktItemDtls.setGemsMobileDktMst(gemsMobileDktMst);
		
		gemsMobileDktItemDtls.setUserId(requestPayload.getBookingInfo().getUserId());
		gemsMobileDktMst.setGemsMobileDktItemDtls(Arrays.asList(gemsMobileDktItemDtls));
		
		dktMstRepo.save(gemsMobileDktMst);
		
		return requestPayload;
	}

}
