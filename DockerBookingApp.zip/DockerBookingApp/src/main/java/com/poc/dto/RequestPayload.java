package com.poc.dto;

import java.util.List;

import lombok.Data;

@Data
public class RequestPayload {

	private BookingInfo bookingInfo;
	private List<DktChrDtl> dktChrDtls;
	private List<DocDetails> docDetails;
	private List<PackageInfo> packageInfo;
	private List<SpecialService> specialService;
	public BookingInfo getBookingInfo() {
		return bookingInfo;
	}
	public void setBookingInfo(BookingInfo bookingInfo) {
		this.bookingInfo = bookingInfo;
	}
	public List<DktChrDtl> getDktChrDtls() {
		return dktChrDtls;
	}
	public void setDktChrDtls(List<DktChrDtl> dktChrDtls) {
		this.dktChrDtls = dktChrDtls;
	}
	public List<DocDetails> getDocDetails() {
		return docDetails;
	}
	public void setDocDetails(List<DocDetails> docDetails) {
		this.docDetails = docDetails;
	}
	public List<PackageInfo> getPackageInfo() {
		return packageInfo;
	}
	public void setPackageInfo(List<PackageInfo> packageInfo) {
		this.packageInfo = packageInfo;
	}
	public List<SpecialService> getSpecialService() {
		return specialService;
	}
	public void setSpecialService(List<SpecialService> specialService) {
		this.specialService = specialService;
	}
	
	
	
	

}
