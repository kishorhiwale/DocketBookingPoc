package com.poc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PackageInfo {
	
	@JsonProperty("Pkg_No")
	private int pkgNo;
	
	@JsonProperty("Act_wt")
	private String actWt;

	public int getPkgNo() {
		return pkgNo;
	}

	public void setPkgNo(int pkgNo) {
		this.pkgNo = pkgNo;
	}

	public String getActWt() {
		return actWt;
	}

	public void setActWt(String actWt) {
		this.actWt = actWt;
	}
	
	
	
	
}
