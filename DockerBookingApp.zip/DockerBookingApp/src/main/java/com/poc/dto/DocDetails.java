package com.poc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class DocDetails {
	@JsonProperty("ACTUAL_DOC_NO")
	private String actualDocNo;
	@JsonProperty("DOC_NO")
	private String docNo;
	
	public String getActualDocNo() {
		return actualDocNo;
	}
	public void setActualDocNo(String actualDocNo) {
		this.actualDocNo = actualDocNo;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	

	
}
