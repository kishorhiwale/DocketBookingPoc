package com.poc.dto;

import lombok.Data;

@Data
public class ReceiverDtls {
	private String consigneeAdd1;
	private String consigneeAdd2;
	
	
	public String getConsigneeAdd1() {
		return consigneeAdd1;
	}
	public void setConsigneeAdd1(String consigneeAdd1) {
		this.consigneeAdd1 = consigneeAdd1;
	}
	public String getConsigneeAdd2() {
		return consigneeAdd2;
	}
	public void setConsigneeAdd2(String consigneeAdd2) {
		this.consigneeAdd2 = consigneeAdd2;
	}
	
	
}
