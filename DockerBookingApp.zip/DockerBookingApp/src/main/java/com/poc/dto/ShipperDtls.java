package com.poc.dto;

import lombok.Data;

@Data
public class ShipperDtls {
	private String bkgrefCode;
	
	private String consignorAdd1;
	
	public String getBkgrefCode() {
		return bkgrefCode;
	}
	public void setBkgrefCode(String bkgrefCode) {
		this.bkgrefCode = bkgrefCode;
	}
	public String getConsignorAdd1() {
		return consignorAdd1;
	}
	public void setConsignorAdd1(String consignorAdd1) {
		this.consignorAdd1 = consignorAdd1;
	}
	
	
}
