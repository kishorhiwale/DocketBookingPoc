package com.poc.dto;


import lombok.Data;

@Data
public class BookingInfo {
	
	private String BillingOu;
	private int docketNo;
	private String userId;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	private ReceiverDtls receiverDtls;
	private ShipperDtls shipperDtls;
	public String getBillingOu() {
		return BillingOu;
	}
	public void setBillingOu(String billingOu) {
		BillingOu = billingOu;
	}
	public int getDocketNo() {
		return docketNo;
	}
	public void setDocketNo(int docketNo) {
		this.docketNo = docketNo;
	}
	public ReceiverDtls getReceiverDtls() {
		return receiverDtls;
	}
	public void setReceiverDtls(ReceiverDtls receiverDtls) {
		this.receiverDtls = receiverDtls;
	}
	public ShipperDtls getShipperDtls() {
		return shipperDtls;
	}
	public void setShipperDtls(ShipperDtls shipperDtls) {
		this.shipperDtls = shipperDtls;
	}
	
	
	
//	
//	private List<DktChrDtl> dktChrDtl;
//	private List<DocDetails> docDetails;
//	private List<PackageInfo> packageInfo;
//	private SpecialService specialService;
//	
	
	
}


