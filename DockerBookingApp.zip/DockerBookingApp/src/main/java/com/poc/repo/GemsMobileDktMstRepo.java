package com.poc.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.poc.entity.GemsMobileDktMst;

@Repository
public interface GemsMobileDktMstRepo extends JpaRepository<GemsMobileDktMst, Integer> {

}
