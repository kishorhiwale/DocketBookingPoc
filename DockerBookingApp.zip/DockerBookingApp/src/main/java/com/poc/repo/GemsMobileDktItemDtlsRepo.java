package com.poc.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.poc.entity.GemsMobileDktItemDtls;


@Repository
public interface GemsMobileDktItemDtlsRepo extends JpaRepository<GemsMobileDktItemDtls, Integer> {

	@Modifying
	@Query(name = "delete from gems_mobile_dkt_item_dtls where gemsMobileDktMst.docket_no =:docketNo", nativeQuery = true)
	boolean deleteByDocketNo(@Param("docketNo") int docketNo);

}
