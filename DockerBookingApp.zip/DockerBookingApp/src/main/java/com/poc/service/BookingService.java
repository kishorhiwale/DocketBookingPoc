package com.poc.service;

import org.apache.catalina.connector.Response;

import com.poc.dto.BookingInfo;
import com.poc.dto.RequestPayload;

public interface BookingService {
	RequestPayload saveBookingInfo(RequestPayload requestPayload); 
}