package com.poc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.dto.RequestPayload;
import com.poc.service.BookingService;

@RestController
@RequestMapping("/api")
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@PostMapping("/save")
	public RequestPayload saveBookingInfo(@RequestBody RequestPayload requestPayload) {
		return bookingService.saveBookingInfo(requestPayload) ;
	}
	
	
	
	
}
